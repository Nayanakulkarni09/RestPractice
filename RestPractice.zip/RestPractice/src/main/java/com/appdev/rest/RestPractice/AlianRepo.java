package com.appdev.rest.RestPractice;

import java.util.ArrayList;
import java.util.List;

public class AlianRepo {
	List<Alian> alianList;

	public AlianRepo() {
		alianList = new ArrayList<Alian>();
		Alian a1 = new Alian();
		a1.setId(1);
		a1.setName("nayana");
		a1.setPoint(100);

		Alian a2 = new Alian();
		a2.setId(2);
		a2.setName("nayana1");
		a2.setPoint(100);
		alianList.add(a1);
		alianList.add(a2);
	}

	public List<Alian> getAlians() {
		return alianList;
	}

	public Alian getAlian(int id) {
		for (Alian a : alianList) {
			if (a.getId() == id) {
				return a;
			}
		}
		return new Alian();

	}
	public Alian createAlian(Alian a) {
		alianList.add(a);
		return a;
	}
}
